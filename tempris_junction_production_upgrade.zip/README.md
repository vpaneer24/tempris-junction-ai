# Tempris Junction AI

A more complete PoC-to-production upgrade starter for Tempris Junction AI.

## Included
- JOINFORCE employee roster
- JUSTPAY payroll preview with CPF/SDL calculations
- JOURNAL finance ledger with burn rate and runway
- JURIS compliance calendar with alert counts
- JUNCTION AI panel with mock/real Anthropic toggle
- Audit trail and JSON export
- Demo data loader

## Setup
```bash
npm install
cp .env.example .env
npm run dev
```

## Notes
- By default, AI runs in mock mode for safe demos.
- To use Anthropic, set `VITE_USE_MOCK_AI=false` and add your API key.
- This starter is stronger than the prior quick PoC, but still needs security, auth, backend persistence, and server-side secrets before true production use.
